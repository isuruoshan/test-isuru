# FirebaseChatAppAndroid
Creating a simple chat application with Firebase on Android
